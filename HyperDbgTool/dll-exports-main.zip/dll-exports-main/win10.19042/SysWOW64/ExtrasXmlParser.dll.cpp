#print comment(linker, "/export:ParseExtrasXmlForExtensionInfo=\"C:\\Windows\\SysWOW64\\ExtrasXmlParser.dll\"")
#print comment(linker, "/export:ParseExtrasXmlForNabSyncExtensionInfo=\"C:\\Windows\\SysWOW64\\ExtrasXmlParser.dll\"")
#print comment(linker, "/export:ParseExtrasXmlForSmsInterceptExtensionInfo=\"C:\\Windows\\SysWOW64\\ExtrasXmlParser.dll\"")
