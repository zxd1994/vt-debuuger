#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\CredProv2faHelper.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\CredProv2faHelper.dll\"")
