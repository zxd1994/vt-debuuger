#print comment(linker, "/export:ExchEntryPoint=\"C:\\Windows\\SysWOW64\\FXSEXT32.dll\"")
