#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\DevicePairing.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\DevicePairing.dll\"")
