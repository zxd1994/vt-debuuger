#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\DeviceFlows.DataModel.dll\"")
#print comment(linker, "/export:DllGetActivationFactory=\"C:\\Windows\\SysWOW64\\DeviceFlows.DataModel.dll\"")
