#print comment(linker, "/export:D3D12GetInterface=\"C:\\Windows\\SysWOW64\\D3D12Core.dll\"")
#print comment(linker, "/export:D3D12SDKVersion=\"C:\\Windows\\SysWOW64\\D3D12Core.dll\"")
