#print comment(linker, "/export:NetSetupGetEngine=\"C:\\Windows\\SysWOW64\\NetSetupEngine.dll\"")
