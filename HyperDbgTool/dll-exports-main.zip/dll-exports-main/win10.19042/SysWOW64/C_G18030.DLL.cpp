#print comment(linker, "/export:NlsDllCodePageTranslation=\"C:\\Windows\\SysWOW64\\C_G18030.DLL\"")
