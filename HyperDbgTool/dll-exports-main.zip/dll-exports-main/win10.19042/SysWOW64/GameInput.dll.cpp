#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\GameInput.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\GameInput.dll\"")
#print comment(linker, "/export:GameInputCreate=\"C:\\Windows\\SysWOW64\\GameInput.dll\"")
