#print comment(linker, "/export:DownlevelGetParentLocaleLCID=\"C:\\Windows\\SysWOW64\\Nlsdl.dll\"")
#print comment(linker, "/export:DownlevelGetParentLocaleName=\"C:\\Windows\\SysWOW64\\Nlsdl.dll\"")
#print comment(linker, "/export:DownlevelLCIDToLocaleName=\"C:\\Windows\\SysWOW64\\Nlsdl.dll\"")
#print comment(linker, "/export:DownlevelLocaleNameToLCID=\"C:\\Windows\\SysWOW64\\Nlsdl.dll\"")
