#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\GameChatTranscription.dll\"")
