#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\DisplayManager.dll\"")
#print comment(linker, "/export:DllGetActivationFactory=\"C:\\Windows\\SysWOW64\\DisplayManager.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\DisplayManager.dll\"")
#print comment(linker, "/export:GetProxyDllInfo=\"C:\\Windows\\SysWOW64\\DisplayManager.dll\"")
