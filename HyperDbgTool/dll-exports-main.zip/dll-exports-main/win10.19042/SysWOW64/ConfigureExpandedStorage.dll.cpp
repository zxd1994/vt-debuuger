#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\ConfigureExpandedStorage.dll\"")
#print comment(linker, "/export:DllGetActivationFactory=\"C:\\Windows\\SysWOW64\\ConfigureExpandedStorage.dll\"")
