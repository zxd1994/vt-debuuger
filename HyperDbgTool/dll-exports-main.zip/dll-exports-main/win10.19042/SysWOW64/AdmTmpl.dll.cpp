#print comment(linker, "/export:CreateCmtStoreObject=\"C:\\Windows\\SysWOW64\\AdmTmpl.dll\"")
#print comment(linker, "/export:CreateParserObject=\"C:\\Windows\\SysWOW64\\AdmTmpl.dll\"")
#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\AdmTmpl.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\AdmTmpl.dll\"")
