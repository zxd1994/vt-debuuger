#print comment(linker, "/export:DXCoreCreateAdapterFactory=\"C:\\Windows\\SysWOW64\\DXCore.dll\"")
