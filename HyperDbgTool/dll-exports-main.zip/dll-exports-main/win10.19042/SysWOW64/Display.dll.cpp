#print comment(linker, "/export:DisplaySaveSettingsEx=\"C:\\Windows\\SysWOW64\\Display.dll\"")
#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\Display.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\Display.dll\"")
#print comment(linker, "/export:ShowAdapterSettings=\"C:\\Windows\\SysWOW64\\Display.dll\"")
