#print comment(linker, "/export:InitializeHeatFramework=\"C:\\Windows\\SysWOW64\\HeatCore.dll\"")
