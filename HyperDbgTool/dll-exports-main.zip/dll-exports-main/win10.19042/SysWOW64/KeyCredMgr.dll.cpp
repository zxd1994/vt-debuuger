#print comment(linker, "/export:KeyCredentialManagerFreeInformation=\"C:\\Windows\\SysWOW64\\KeyCredMgr.dll\"")
#print comment(linker, "/export:KeyCredentialManagerGetInformation=\"C:\\Windows\\SysWOW64\\KeyCredMgr.dll\"")
#print comment(linker, "/export:KeyCredentialManagerGetOperationErrorStates=\"C:\\Windows\\SysWOW64\\KeyCredMgr.dll\"")
#print comment(linker, "/export:KeyCredentialManagerShowUIOperation=\"C:\\Windows\\SysWOW64\\KeyCredMgr.dll\"")
