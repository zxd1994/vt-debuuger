#print comment(linker, "/export:CreateMapGeocoderFactory=\"C:\\Windows\\SysWOW64\\MapGeocoder.dll\"")
