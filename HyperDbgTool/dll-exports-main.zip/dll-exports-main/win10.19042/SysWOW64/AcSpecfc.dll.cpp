#print comment(linker, "/export:CleanupIS=\"C:\\Windows\\SysWOW64\\AcSpecfc.dll\"")
#print comment(linker, "/export:GetHookAPIs=\"C:\\Windows\\SysWOW64\\AcSpecfc.dll\"")
#print comment(linker, "/export:NotifyShims=\"C:\\Windows\\SysWOW64\\AcSpecfc.dll\"")
#print comment(linker, "/export:StiCreateInstanceA=\"C:\\Windows\\SysWOW64\\AcSpecfc.dll\"")
