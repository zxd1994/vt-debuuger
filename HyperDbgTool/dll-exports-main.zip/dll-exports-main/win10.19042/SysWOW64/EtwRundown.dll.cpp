#print comment(linker, "/export:EtwLogHeapRundown=\"C:\\Windows\\SysWOW64\\EtwRundown.dll\"")
#print comment(linker, "/export:EtwLogSysConfigRundown=\"C:\\Windows\\SysWOW64\\EtwRundown.dll\"")
