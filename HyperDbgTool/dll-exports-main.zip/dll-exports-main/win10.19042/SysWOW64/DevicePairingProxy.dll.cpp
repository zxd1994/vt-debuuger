#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\DevicePairingProxy.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\DevicePairingProxy.dll\"")
#print comment(linker, "/export:DllRegisterServer=\"C:\\Windows\\SysWOW64\\DevicePairingProxy.dll\"")
#print comment(linker, "/export:DllUnregisterServer=\"C:\\Windows\\SysWOW64\\DevicePairingProxy.dll\"")
