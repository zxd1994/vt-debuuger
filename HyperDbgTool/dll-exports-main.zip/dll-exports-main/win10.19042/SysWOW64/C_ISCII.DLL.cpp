#print comment(linker, "/export:NlsDllCodePageTranslation=\"C:\\Windows\\SysWOW64\\C_ISCII.DLL\"")
