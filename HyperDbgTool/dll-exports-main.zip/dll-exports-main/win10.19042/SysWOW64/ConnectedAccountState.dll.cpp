#print comment(linker, "/export:ActionCenterRunDllW=\"C:\\Windows\\SysWOW64\\ConnectedAccountState.dll\"")
#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\ConnectedAccountState.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\ConnectedAccountState.dll\"")
