#print comment(linker, "/export:DllMain=\"C:\\Windows\\SysWOW64\\NapiNSP.dll\"")
#print comment(linker, "/export:NSPStartup=\"C:\\Windows\\SysWOW64\\NapiNSP.dll\"")
