#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\DDOIProxy.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\DDOIProxy.dll\"")
