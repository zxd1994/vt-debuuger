#print comment(linker, "/export:TeapExt_EapPeerInvokeConfigUI=\"C:\\Windows\\SysWOW64\\EapTeapExt.dll\"")
#print comment(linker, "/export:TtlsExt_FreeMemoryExt=\"C:\\Windows\\SysWOW64\\EapTeapExt.dll\"")
