#print comment(linker, "/export:FwRpcAPIsInitialize=\"C:\\Windows\\SysWOW64\\FwRemoteSvr.dll\"")
#print comment(linker, "/export:FwRpcAPIsShutdown=\"C:\\Windows\\SysWOW64\\FwRemoteSvr.dll\"")
