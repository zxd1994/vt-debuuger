#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\MFCaptureEngine.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\MFCaptureEngine.dll\"")
#print comment(linker, "/export:MFCreateCaptureEngine=\"C:\\Windows\\SysWOW64\\MFCaptureEngine.dll\"")
