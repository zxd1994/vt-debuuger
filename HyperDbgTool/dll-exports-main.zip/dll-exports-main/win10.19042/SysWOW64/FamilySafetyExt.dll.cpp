#print comment(linker, "/export:IsChildAccount=\"C:\\Windows\\SysWOW64\\FamilySafetyExt.dll\"")
