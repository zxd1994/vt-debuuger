#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\AnalogCommonProxyStub.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\AnalogCommonProxyStub.dll\"")
#print comment(linker, "/export:GetProxyDllInfo=\"C:\\Windows\\SysWOW64\\AnalogCommonProxyStub.dll\"")
