#print comment(linker, "/export:ConfigurationManager_Create=\"C:\\Windows\\SysWOW64\\MapConfiguration.dll\"")
#print comment(linker, "/export:ConfigurationManager_GetLocaleMapConfiguration=\"C:\\Windows\\SysWOW64\\MapConfiguration.dll\"")
#print comment(linker, "/export:ConfigurationManager_SetCustomStorageFolder=\"C:\\Windows\\SysWOW64\\MapConfiguration.dll\"")
#print comment(linker, "/export:ConfigurationManager_SetServiceCallbacks=\"C:\\Windows\\SysWOW64\\MapConfiguration.dll\"")
