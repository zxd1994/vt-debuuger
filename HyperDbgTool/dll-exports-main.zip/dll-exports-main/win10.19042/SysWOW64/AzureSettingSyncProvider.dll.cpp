#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\AzureSettingSyncProvider.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\AzureSettingSyncProvider.dll\"")
