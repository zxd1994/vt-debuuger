#print comment(linker, "/export:OrdinalOne=\"C:\\Windows\\SysWOW64\\Microsoft.Uev.AppAgent.dll\"")
