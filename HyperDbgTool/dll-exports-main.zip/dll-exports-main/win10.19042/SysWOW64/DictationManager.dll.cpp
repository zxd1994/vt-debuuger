#print comment(linker, "/export:CreateDictationManager=\"C:\\Windows\\SysWOW64\\DictationManager.dll\"")
#print comment(linker, "/export:CreateDictationManagerWithDeviceController=\"C:\\Windows\\SysWOW64\\DictationManager.dll\"")
