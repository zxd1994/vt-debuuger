#print comment(linker, "/export:GetIndexedDbLegacyFunctions=\"C:\\Windows\\SysWOW64\\IndexedDbLegacy.dll\"")
