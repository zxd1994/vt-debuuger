#print comment(linker, "/export:DllMain=\"C:\\Windows\\SysWOW64\\EhStorPwdMgr.dll\"")
#print comment(linker, "/export:EnhancedStoragePasswordConfig=\"C:\\Windows\\SysWOW64\\EhStorPwdMgr.dll\"")
#print comment(linker, "/export:EnhancedStoragePasswordInitDisk=\"C:\\Windows\\SysWOW64\\EhStorPwdMgr.dll\"")
