#print comment(linker, "/export:LangDataCall=\"C:\\Windows\\SysWOW64\\NlsData0000.dll\"")
