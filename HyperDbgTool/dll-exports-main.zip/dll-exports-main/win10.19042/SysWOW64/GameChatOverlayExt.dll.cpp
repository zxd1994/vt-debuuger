#print comment(linker, "/export:GcoAddMessage=\"C:\\Windows\\SysWOW64\\GameChatOverlayExt.dll\"")
#print comment(linker, "/export:GcoGetDesiredPosition=\"C:\\Windows\\SysWOW64\\GameChatOverlayExt.dll\"")
#print comment(linker, "/export:GcoSetDesiredPosition=\"C:\\Windows\\SysWOW64\\GameChatOverlayExt.dll\"")
