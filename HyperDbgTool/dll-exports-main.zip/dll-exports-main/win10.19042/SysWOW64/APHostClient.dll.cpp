#print comment(linker, "/export:ApHostServerStatus_EnsureServerReady=\"C:\\Windows\\SysWOW64\\APHostClient.dll\"")
#print comment(linker, "/export:CreateAPHostClient=\"C:\\Windows\\SysWOW64\\APHostClient.dll\"")
