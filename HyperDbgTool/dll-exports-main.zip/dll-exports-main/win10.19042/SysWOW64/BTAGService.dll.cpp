#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\BTAGService.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\BTAGService.dll\"")
#print comment(linker, "/export:ServiceMain=\"C:\\Windows\\SysWOW64\\BTAGService.dll\"")
#print comment(linker, "/export:SvchostPushServiceGlobals=\"C:\\Windows\\SysWOW64\\BTAGService.dll\"")
