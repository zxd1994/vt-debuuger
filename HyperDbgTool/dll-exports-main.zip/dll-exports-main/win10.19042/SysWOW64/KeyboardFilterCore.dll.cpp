#print comment(linker, "/export:HookMain=\"C:\\Windows\\SysWOW64\\KeyboardFilterCore.dll\"")
