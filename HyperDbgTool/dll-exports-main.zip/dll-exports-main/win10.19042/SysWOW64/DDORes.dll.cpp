#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\DDORes.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\DDORes.dll\"")
