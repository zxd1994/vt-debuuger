#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\MSVP9DEC.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\MSVP9DEC.dll\"")
