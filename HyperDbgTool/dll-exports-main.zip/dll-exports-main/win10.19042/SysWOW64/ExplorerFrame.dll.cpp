#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\ExplorerFrame.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\ExplorerFrame.dll\"")
#print comment(linker, "/export:DllGetVersion=\"C:\\Windows\\SysWOW64\\ExplorerFrame.dll\"")
