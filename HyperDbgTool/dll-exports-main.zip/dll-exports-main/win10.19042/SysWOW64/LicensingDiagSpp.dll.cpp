#print comment(linker, "/export:InitializeCollector=\"C:\\Windows\\SysWOW64\\LicensingDiagSpp.dll\"")
