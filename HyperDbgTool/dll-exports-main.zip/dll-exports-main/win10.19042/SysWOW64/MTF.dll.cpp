#print comment(linker, "/export:CreateInputTypeAttributes=\"C:\\Windows\\SysWOW64\\MTF.dll\"")
#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\MTF.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\MTF.dll\"")
