#print comment(linker, "/export:DWriteCreateFactory=\"C:\\Windows\\SysWOW64\\DWrite.dll\"")
