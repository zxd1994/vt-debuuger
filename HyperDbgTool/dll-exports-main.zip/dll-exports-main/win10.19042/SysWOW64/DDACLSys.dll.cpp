#print comment(linker, "/export:DDACLSys_Offline_Specialize=\"C:\\Windows\\SysWOW64\\DDACLSys.dll\"")
#print comment(linker, "/export:DDACLSys_Specialize=\"C:\\Windows\\SysWOW64\\DDACLSys.dll\"")
