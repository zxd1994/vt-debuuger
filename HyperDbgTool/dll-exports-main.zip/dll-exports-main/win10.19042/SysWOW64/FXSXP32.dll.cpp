#print comment(linker, "/export:ServiceEntry=\"C:\\Windows\\SysWOW64\\FXSXP32.dll\"")
#print comment(linker, "/export:XPProviderInit=\"C:\\Windows\\SysWOW64\\FXSXP32.dll\"")
