#print comment(linker, "/export:CreateMetafileRenderer=\"C:\\Windows\\SysWOW64\\Direct2DDesktop.dll\"")
