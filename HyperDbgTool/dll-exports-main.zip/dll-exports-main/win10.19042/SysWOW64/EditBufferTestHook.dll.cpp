#print comment(linker, "/export:CreateEditBufferTestHook=\"C:\\Windows\\SysWOW64\\EditBufferTestHook.dll\"")
#print comment(linker, "/export:CreateEditBufferTestHookClient=\"C:\\Windows\\SysWOW64\\EditBufferTestHook.dll\"")
#print comment(linker, "/export:EnableTestHook=\"C:\\Windows\\SysWOW64\\EditBufferTestHook.dll\"")
#print comment(linker, "/export:GetTestHookEnabled=\"C:\\Windows\\SysWOW64\\EditBufferTestHook.dll\"")
