#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\CameraCaptureUI.dll\"")
#print comment(linker, "/export:DllGetActivationFactory=\"C:\\Windows\\SysWOW64\\CameraCaptureUI.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\CameraCaptureUI.dll\"")
