#print comment(linker, "/export:DllCanUnloadNow=\"C:\\Windows\\SysWOW64\\MSAlacDecoder.dll\"")
#print comment(linker, "/export:DllGetClassObject=\"C:\\Windows\\SysWOW64\\MSAlacDecoder.dll\"")
