#print comment(linker, "/export:GetHookAPIs=\"C:\\Windows\\SysWOW64\\AcWinRT.dll\"")
#print comment(linker, "/export:NotifyShims=\"C:\\Windows\\SysWOW64\\AcWinRT.dll\"")
