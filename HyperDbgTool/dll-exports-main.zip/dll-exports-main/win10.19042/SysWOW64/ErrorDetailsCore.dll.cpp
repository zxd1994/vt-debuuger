#print comment(linker, "/export:FreeErrorDetails=\"C:\\Windows\\SysWOW64\\ErrorDetailsCore.dll\"")
#print comment(linker, "/export:GetErrorDetails=\"C:\\Windows\\SysWOW64\\ErrorDetailsCore.dll\"")
#print comment(linker, "/export:GetErrorDetailsWithContext=\"C:\\Windows\\SysWOW64\\ErrorDetailsCore.dll\"")
