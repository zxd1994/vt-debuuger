#print comment(linker, "/export:WdiDiagnosticModuleMain=\"C:\\Windows\\SysWOW64\\Apphlpdm.dll\"")
#print comment(linker, "/export:WdiGetDiagnosticModuleInterfaceVersion=\"C:\\Windows\\SysWOW64\\Apphlpdm.dll\"")
#print comment(linker, "/export:WdiHandleInstance=\"C:\\Windows\\SysWOW64\\Apphlpdm.dll\"")
