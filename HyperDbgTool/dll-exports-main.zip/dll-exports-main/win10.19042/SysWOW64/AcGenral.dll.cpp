#print comment(linker, "/export:GetHookAPIs=\"C:\\Windows\\SysWOW64\\AcGenral.dll\"")
#print comment(linker, "/export:NotifyShims=\"C:\\Windows\\SysWOW64\\AcGenral.dll\"")
