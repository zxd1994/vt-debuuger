#print comment(linker, "/export:HookMain=\"C:\\Windows\\SysWOW64\\DialogBlockerProc.dll\"")
