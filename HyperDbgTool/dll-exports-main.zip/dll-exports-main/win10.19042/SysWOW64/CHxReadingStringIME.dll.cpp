#print comment(linker, "/export:GetReadingString=\"C:\\Windows\\SysWOW64\\CHxReadingStringIME.dll\"")
#print comment(linker, "/export:ShowReadingWindow=\"C:\\Windows\\SysWOW64\\CHxReadingStringIME.dll\"")
