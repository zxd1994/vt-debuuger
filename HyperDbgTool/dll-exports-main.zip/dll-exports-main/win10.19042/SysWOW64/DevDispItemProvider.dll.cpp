#print comment(linker, "/export:DevQueryEntry=\"C:\\Windows\\SysWOW64\\DevDispItemProvider.dll\"")
