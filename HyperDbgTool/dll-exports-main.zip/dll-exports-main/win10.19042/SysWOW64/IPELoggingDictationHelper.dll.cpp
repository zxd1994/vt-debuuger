#print comment(linker, "/export:GetIPELoggingHelper=\"C:\\Windows\\SysWOW64\\IPELoggingDictationHelper.dll\"")
