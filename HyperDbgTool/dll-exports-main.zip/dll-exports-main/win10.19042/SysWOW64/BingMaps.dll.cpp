#print comment(linker, "/export:GetBingMapsFactory=\"C:\\Windows\\SysWOW64\\BingMaps.dll\"")
