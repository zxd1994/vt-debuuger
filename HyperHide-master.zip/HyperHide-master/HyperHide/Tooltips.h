#pragma once
#include <Windows.h>
HWND CreateTooltips(HWND hDlg);