1.HyperHide.dp64是x64dbg插件. 放到x64dbg/plgin 目录下
2.自动下载pdb符号文件